def ops():
    op = ["change_route",
          "most_expensive_one_reinsert_from_dummy",
          "move_to_next_valid_vehicle",
          "move_vehicle_to_dummy",
          "one_reinsert_from_dummy",
          "one_reinsert_most_expensive_call",
          "swap",
          "shuffle",
          "take_from_dummy_place_first_suitable",
          "triple_swap",
          "x_one_reinserts_inside_vehicle",
          "x_one_reinserts_inside_vehicle_dsc"
          ]
    return op
